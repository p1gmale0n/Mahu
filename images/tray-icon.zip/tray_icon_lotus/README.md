# TrayIconTemplate

Monochrome macOS menu bar/tray template icon based on the provided lotus icon.

Files:
- `TrayIconTemplate.svg` — vector source, black strokes on transparent background.
- `TrayIconTemplate.pdf` — vector PDF, useful for Xcode asset catalogs.
- `appkit_18pt/TrayIconTemplate.png` — 18x18 px @1x.
- `appkit_18pt/TrayIconTemplate@2x.png` — 36x36 px @2x.
- `compact_16pt/TrayIconTemplate.png` — 16x16 px @1x.
- `compact_16pt/TrayIconTemplate@2x.png` — 32x32 px @2x.
- `XcodeAssets/TrayIconTemplate.imageset/` — ready-to-copy Xcode image set using the 18pt pair and template rendering intent.
- `preview/` — visual previews only; do not ship these preview PNGs as app assets.

All asset PNGs contain only black pixels with alpha transparency. No background, gradients, or shadows.

Native AppKit example:

```swift
let statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
if let image = NSImage(named: "TrayIconTemplate") {
    image.isTemplate = true
    image.size = NSSize(width: 18, height: 18)
    statusItem.button?.image = image
}
```

SwiftUI MenuBarExtra example:

```swift
MenuBarExtra {
    // menu content
} label: {
    Image("TrayIconTemplate")
        .renderingMode(.template)
}
```
